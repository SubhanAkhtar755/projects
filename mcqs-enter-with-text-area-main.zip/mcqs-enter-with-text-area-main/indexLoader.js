setTimeout(()=>{
window.location.href = './rules.html'
},4000)